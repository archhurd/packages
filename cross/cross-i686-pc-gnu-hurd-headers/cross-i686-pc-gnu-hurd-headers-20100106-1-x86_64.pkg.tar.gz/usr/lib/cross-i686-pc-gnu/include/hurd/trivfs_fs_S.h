#ifndef	_fs_server_
#define	_fs_server_

/* Module fs */

#include <mach/kern_return.h>
#include <mach/port.h>
#include <mach/message.h>

#include <mach/std_types.h>
#include <mach/mach_types.h>
#include <device/device_types.h>
#include <device/net_status.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/resource.h>
#include <sys/utsname.h>
#include <hurd/hurd_types.h>
#include <hurd/trivfs.h>

/* Routine file_exec */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_exec
(
	trivfs_protid_t exec_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t exec_task,
	int flags,
	data_t argv,
	mach_msg_type_number_t argvCnt,
	data_t envp,
	mach_msg_type_number_t envpCnt,
	portarray_t fdarray,
	mach_msg_type_number_t fdarrayCnt,
	portarray_t portarray,
	mach_msg_type_number_t portarrayCnt,
	intarray_t intarray,
	mach_msg_type_number_t intarrayCnt,
	mach_port_array_t deallocnames,
	mach_msg_type_number_t deallocnamesCnt,
	mach_port_array_t destroynames,
	mach_msg_type_number_t destroynamesCnt
);

/* Routine file_chown */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_chown
(
	trivfs_protid_t chown_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	uid_t new_owner,
	gid_t new_group
);

/* Routine file_chauthor */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_chauthor
(
	trivfs_protid_t chauth_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	uid_t new_author
);

/* Routine file_chmod */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_chmod
(
	trivfs_protid_t chmod_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mode_t new_mode
);

/* Routine file_chflags */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_chflags
(
	trivfs_protid_t chflags_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int new_flags
);

/* Routine file_utimes */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_utimes
(
	trivfs_protid_t utimes_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	time_value_t new_atime,
	time_value_t new_mtime
);

/* Routine file_set_size */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_set_size
(
	trivfs_protid_t trunc_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	loff_t new_size
);

/* Routine file_lock */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_lock
(
	trivfs_protid_t lock_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int flags
);

/* Routine file_lock_stat */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_lock_stat
(
	trivfs_protid_t lock_file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int *mystatus,
	int *otherstatus
);

/* Routine file_check_access */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_check_access
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int *allowed
);

/* Routine file_notice_changes */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_notice_changes
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t port
);

/* Routine file_getcontrol */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_getcontrol
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *control,
	mach_msg_type_name_t *controlPoly
);

/* Routine file_statfs */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_statfs
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	fsys_statfsbuf_t *info
);

/* Routine file_sync */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_sync
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int wait,
	int omit_metadata
);

/* Routine file_syncfs */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_syncfs
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int wait,
	int do_children
);

/* Routine file_get_storage_info */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_get_storage_info
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	portarray_t *ports,
	mach_msg_type_name_t *portsPoly,
	mach_msg_type_number_t *portsCnt,
	intarray_t *ints,
	mach_msg_type_number_t *intsCnt,
	off_array_t *offsets,
	mach_msg_type_number_t *offsetsCnt,
	data_t *data,
	mach_msg_type_number_t *dataCnt
);

/* Routine file_getlinknode */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_getlinknode
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *linknode,
	mach_msg_type_name_t *linknodePoly
);

/* Routine file_getfh */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_getfh
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	data_t *filehandle,
	mach_msg_type_number_t *filehandleCnt
);

/* Routine dir_lookup */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_lookup
(
	trivfs_protid_t start_dir,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	string_t file_name,
	int flags,
	mode_t mode,
	retry_type *do_retry,
	string_t retry_name,
	mach_port_t *result,
	mach_msg_type_name_t *resultPoly
);

/* Routine dir_readdir */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_readdir
(
	trivfs_protid_t dir,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	data_t *data,
	mach_msg_type_number_t *dataCnt,
	boolean_t *dataDealloc,
	int entry,
	int nentries,
	vm_size_t bufsiz,
	int *amount
);

/* Routine dir_mkdir */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_mkdir
(
	trivfs_protid_t directory,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	string_t name,
	mode_t mode
);

/* Routine dir_rmdir */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_rmdir
(
	trivfs_protid_t directory,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	string_t name
);

/* Routine dir_unlink */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_unlink
(
	trivfs_protid_t directory,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	string_t name
);

/* Routine dir_link */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_link
(
	trivfs_protid_t dir,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	trivfs_protid_t file,
	string_t name,
	int excl
);

/* Routine dir_rename */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_rename
(
	trivfs_protid_t olddirectory,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	string_t oldname,
	trivfs_protid_t newdirectory,
	string_t newname,
	int excl
);

/* Routine dir_mkfile */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_mkfile
(
	trivfs_protid_t directory,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int flags,
	mode_t mode,
	mach_port_t *newnode,
	mach_msg_type_name_t *newnodePoly
);

/* Routine dir_notice_changes */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_dir_notice_changes
(
	trivfs_protid_t directory,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t port
);

/* Routine file_set_translator */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_set_translator
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int passive_flags,
	int active_flags,
	int oldtrans_flags,
	data_t passive,
	mach_msg_type_number_t passiveCnt,
	mach_port_t active
);

/* Routine file_get_translator */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_get_translator
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	data_t *translator,
	mach_msg_type_number_t *translatorCnt
);

/* Routine file_get_translator_cntl */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_get_translator_cntl
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *translator_cntl,
	mach_msg_type_name_t *translator_cntlPoly
);

/* Routine file_get_fs_options */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_get_fs_options
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	data_t *options,
	mach_msg_type_number_t *optionsCnt
);

/* Routine file_reparent */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_file_reparent
(
	trivfs_protid_t file,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t parent,
	mach_port_t *new_file,
	mach_msg_type_name_t *new_filePoly
);

#endif	/* not defined(_fs_server_) */
