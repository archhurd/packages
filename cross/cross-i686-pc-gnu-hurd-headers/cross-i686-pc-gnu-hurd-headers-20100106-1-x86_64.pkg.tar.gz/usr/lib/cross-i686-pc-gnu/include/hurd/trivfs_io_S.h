#ifndef	_io_server_
#define	_io_server_

/* Module io */

#include <mach/kern_return.h>
#include <mach/port.h>
#include <mach/message.h>

#include <mach/std_types.h>
#include <mach/mach_types.h>
#include <device/device_types.h>
#include <device/net_status.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/resource.h>
#include <sys/utsname.h>
#include <hurd/hurd_types.h>
#include <hurd/trivfs.h>

/* Routine io_write */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_write
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	data_t data,
	mach_msg_type_number_t dataCnt,
	loff_t offset,
	vm_size_t *amount
);

/* Routine io_read */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_read
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	data_t *data,
	mach_msg_type_number_t *dataCnt,
	loff_t offset,
	vm_size_t amount
);

/* Routine io_seek */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_seek
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	loff_t offset,
	int whence,
	loff_t *newp
);

/* Routine io_readable */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_readable
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	vm_size_t *amount
);

/* Routine io_set_all_openmodes */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_set_all_openmodes
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int newbits
);

/* Routine io_get_openmodes */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_get_openmodes
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int *bits
);

/* Routine io_set_some_openmodes */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_set_some_openmodes
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int bits_to_set
);

/* Routine io_clear_some_openmodes */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_clear_some_openmodes
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int bits_to_clear
);

/* Routine io_async */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_async
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t notify_port,
	mach_port_t *async_id_port,
	mach_msg_type_name_t *async_id_portPoly
);

/* Routine io_mod_owner */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_mod_owner
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	pid_t owner
);

/* Routine io_get_owner */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_get_owner
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	pid_t *owner
);

/* Routine io_get_icky_async_id */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_get_icky_async_id
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *icky_async_id_port,
	mach_msg_type_name_t *icky_async_id_portPoly
);

/* Routine io_select */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_select
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int *select_type
);

/* Routine io_stat */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_stat
(
	trivfs_protid_t stat_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	io_statbuf_t *stat_info
);

/* SimpleRoutine io_reauthenticate */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_reauthenticate
(
	trivfs_protid_t auth_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t rendezvous2
);

/* Routine io_restrict_auth */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_restrict_auth
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *new_object,
	mach_msg_type_name_t *new_objectPoly,
	idarray_t uids,
	mach_msg_type_number_t uidsCnt,
	idarray_t gids,
	mach_msg_type_number_t gidsCnt
);

/* Routine io_duplicate */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_duplicate
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *newport,
	mach_msg_type_name_t *newportPoly
);

/* Routine io_server_version */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_server_version
(
	trivfs_protid_t vers_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	string_t server_name,
	int *server_major_version,
	int *server_minor_version,
	int *server_edit_level
);

/* Routine io_map */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_map
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *memobjrd,
	mach_msg_type_name_t *memobjrdPoly,
	mach_port_t *memobjwt,
	mach_msg_type_name_t *memobjwtPoly
);

/* Routine io_map_cntl */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_map_cntl
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *memobj,
	mach_msg_type_name_t *memobjPoly
);

/* Routine io_get_conch */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_get_conch
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly
);

/* Routine io_release_conch */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_release_conch
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly
);

/* Routine io_eofnotify */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_eofnotify
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly
);

/* Routine io_prenotify */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_prenotify
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	vm_offset_t write_start,
	vm_offset_t write_end
);

/* Routine io_postnotify */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_postnotify
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	vm_offset_t write_start,
	vm_offset_t write_end
);

/* Routine io_readnotify */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_readnotify
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly
);

/* Routine io_readsleep */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_readsleep
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly
);

/* Routine io_sigio */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_sigio
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly
);

/* Routine io_pathconf */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_pathconf
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int name,
	int *value
);

/* Routine io_identity */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_identity
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *idport,
	mach_msg_type_name_t *idportPoly,
	mach_port_t *fsidport,
	mach_msg_type_name_t *fsidportPoly,
	ino64_t *fileno
);

/* Routine io_revoke */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_io_revoke
(
	trivfs_protid_t io_object,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly
);

#endif	/* not defined(_io_server_) */
