#ifndef	_fsys_server_
#define	_fsys_server_

/* Module fsys */

#include <mach/kern_return.h>
#include <mach/port.h>
#include <mach/message.h>

#include <mach/std_types.h>
#include <mach/mach_types.h>
#include <device/device_types.h>
#include <device/net_status.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/resource.h>
#include <sys/utsname.h>
#include <hurd/hurd_types.h>
#include <hurd/trivfs.h>

/* Routine fsys_startup */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_startup
(
	mach_port_t bootstrap,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int openflags,
	mach_port_t control_port,
	mach_port_t *realnode,
	mach_msg_type_name_t *realnodePoly
);

/* Routine fsys_goaway */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_goaway
(
	trivfs_control_t fsys,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int flags
);

/* Routine fsys_getroot */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_getroot
(
	trivfs_control_t fsys,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t dotdot_node,
	idarray_t gen_uids,
	mach_msg_type_number_t gen_uidsCnt,
	idarray_t gen_gids,
	mach_msg_type_number_t gen_gidsCnt,
	int flags,
	retry_type *do_retry,
	string_t retry_name,
	mach_port_t *file,
	mach_msg_type_name_t *filePoly
);

/* Routine fsys_getfile */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_getfile
(
	trivfs_control_t fsys,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	idarray_t gen_uids,
	mach_msg_type_number_t gen_uidsCnt,
	idarray_t gen_gids,
	mach_msg_type_number_t gen_gidsCnt,
	data_t filehandle,
	mach_msg_type_number_t filehandleCnt,
	mach_port_t *file,
	mach_msg_type_name_t *filePoly
);

/* Routine fsys_syncfs */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_syncfs
(
	trivfs_control_t fsys,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	int wait,
	int do_children
);

/* Routine fsys_set_options */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_set_options
(
	trivfs_control_t fsys,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	data_t options,
	mach_msg_type_number_t optionsCnt,
	int do_children
);

/* Routine fsys_getpriv */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_getpriv
(
	trivfs_control_t fsys,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t *host_priv,
	mach_msg_type_name_t *host_privPoly,
	mach_port_t *device_master,
	mach_msg_type_name_t *device_masterPoly,
	mach_port_t *fstask,
	mach_msg_type_name_t *fstaskPoly
);

/* Routine fsys_init */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_init
(
	trivfs_control_t fsys,
	mach_port_t reply_port,
	mach_msg_type_name_t reply_portPoly,
	mach_port_t proc_server,
	auth_t auth_handle
);

/* Routine fsys_forward */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_forward
(
	mach_port_t server,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	mach_port_t requestor,
	data_t argv,
	mach_msg_type_number_t argvCnt
);

/* Routine fsys_get_options */
#ifdef	mig_external
mig_external
#else
extern
#endif
kern_return_t trivfs_S_fsys_get_options
(
	trivfs_control_t server,
	mach_port_t reply,
	mach_msg_type_name_t replyPoly,
	data_t *options,
	mach_msg_type_number_t *optionsCnt
);

#endif	/* not defined(_fsys_server_) */
